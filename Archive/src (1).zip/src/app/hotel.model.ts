export class Hotel {
    
        hotelId!: number;
        hotelName!: string;
        hotelAddress!: string;
        hotelPhoneNo!: string;
        hotelLocation!: string;
        description!: string;
    
            constructor(id: number, name: string, address: string, phoneno: string, location:string, desc: string){
                this.hotelId = id;
                this.hotelName = name;
                this.hotelAddress = address;
                this.hotelPhoneNo = phoneno;
                this.hotelLocation = location;
                this.description = desc;
            }
    
    
    
}
