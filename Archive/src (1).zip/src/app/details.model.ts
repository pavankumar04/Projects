export class Details {
  guestId!: number;
  hotelId!: number;
  roomId!: number;
  cost!: number;
}
