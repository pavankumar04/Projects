import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-listroomsadmin',
  templateUrl: './listroomsadmin.component.html',
  styleUrls: ['./listroomsadmin.component.css']
})
export class ListroomsadminComponent implements OnInit {
  room!: Room[];



  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute ) { }

  ngOnInit(): void {
    this.retrieveRooms();
    
    
    
  }
  

  retrieveRooms():void{
    this.roomservice.listAllRooms()
    .subscribe(
      data=>{
        console.log(data);
        this.room=data;
        
        
      }
    )
  
}
showRoomById(id: number){
  this.router.navigate(['/detailsadmin',id]); 
}
show(){
  this.router.navigate(['SearchByType']);
}
listByAvail(){
  this.router.navigate(['RoomsAvail'])
}
fil(){
  this.router.navigate(['fil']);
}
home(){
  this.router.navigate(['']);
}
roombyid(){
  this.router.navigate(['searchbyid']);
}
showhid(){
  this.router.navigate(['searchhid']);
}
admin(){
  this.router.navigate(['admin']);
}


}