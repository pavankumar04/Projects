import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListroomsadminComponent } from './listroomsadmin.component';

describe('ListroomsadminComponent', () => {
  let component: ListroomsadminComponent;
  let fixture: ComponentFixture<ListroomsadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListroomsadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListroomsadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
