import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  room!: Room[];
  cost!:number;
  re!:number;

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    
  }
  listByFilter(){
    if(this.cost<=0){
      alert("ENTER VALID AMOUNT");
    }
    this.roomservice.listByFilter(this.cost)
    .subscribe( data => {
      console.log(data);
      this.room =data;
      if(data.length==0){
        alert("NO ROOMS UNDER YOUR BUDGET")
      }
    },error=>{alert("ENTER VALID AMOUNT")});
      

}
  showRoomById(id: number){
    this.router.navigate(['/details',id]); 
  }
  listByAvail(){
    this.router.navigate(['RoomsAvail'])
  }
  home(){
    this.router.navigate([''])
  }
}
