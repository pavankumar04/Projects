import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Hotel } from './hotel.model';
import { map } from "rxjs/operators";



const baseUrl = 'http://localhost:8086/api/hotel';
@Injectable({
  providedIn: 'root'
})
export class HotelService {

  constructor(private http: HttpClient) { }

  getAllHotels(): Observable<Hotel[]>{
    return this.http.get<Hotel[]>(baseUrl);
  }

  getHotelByLocation(location: string): Observable<Hotel[]>{
    return this.http.get<Hotel[]>(`${baseUrl}/location/${location}`);
  }

  getHotelById(id: number): Observable<Hotel>{
    return this.http.get<Hotel>(`${baseUrl}/${id}`);
  }

  addNewHotel(hotel: Hotel): Observable<any>{
    return this.http.post(`${baseUrl}`, hotel,
    {headers: {'content-type': 'application/json'},observe: 'response',responseType: 'text'})
    .pipe(map(data => {
      console.log(data.body);
      return data.body;
    }));
  }

  deleteHotel(id: number): Observable<any>{
    return this.http.delete(`${baseUrl}/remove/${id}`,  
    {headers: {'content-type': 'application/json'},observe: 'response',responseType: 'text'})
    .pipe(map(data => {
      console.log(data.body);
      return data.body;
    }));
  }

  updatePhoneNo(hotel: Hotel): Observable<any>{
    return this.http.put(`${baseUrl}/phoneno/${hotel.hotelPhoneNo}/${hotel.hotelId}`, hotel,
    {headers: {'content-type': 'application/json'},observe: 'response',responseType: 'text'})
    .pipe(map(data => {
      console.log(data.body);
      return data.body;
    }));
  }

  updateDesc(hotel: Hotel): Observable<any>{
    return this.http.put(`${baseUrl}/description/${hotel.description}/${hotel.hotelId}`, hotel,
    {headers: {'content-type': 'application/json'},observe: 'response',responseType: 'text'})
    .pipe(map(data => {
      console.log(data.body);
      return data.body;
    }));
  }
}
