import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute ) { }

  ngOnInit(): void {
  }
  retrieveRooms(){
    this.router.navigate(['listroomsadmin']);
  }
  addroom(){
    this.router.navigate(['addroom'])
  }
  showid(){
    this.router.navigate(['searchbyid'])
  }
  showhid(){
    this.router.navigate(['searchhid'])

  }
  roomcost(){
    this.router.navigate(['cost'])
  }
  home(){
    this.router.navigate([''])
  }
  adminhotel(){
    this.router.navigate(['Admin_function'])
  }
  goToList(){
    this.router.navigate(['Admin_hotelList']);
  }

}
