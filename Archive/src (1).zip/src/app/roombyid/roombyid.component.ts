import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { asLiteral } from '@angular/compiler/src/render3/view/util';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-roombyid',
  templateUrl: './roombyid.component.html',
  styleUrls: ['./roombyid.component.css']
})
export class RoombyidComponent implements OnInit {
  room!: Room;
  id!: number;

constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

ngOnInit(): void {
  

}
showRoomById(){
  if(this.id <=0 ||  this.id>=1000){
    alert("CHECK ROOM ID")
  }
  else{
  this.roomservice.getRoomById(this.id)
  .subscribe(data => {
    console.log(data);
    this.room=data
  },error=>{alert("ROOM ID NOT VALID")});
}
}
home(){
  this.router.navigate(['']);
}
showRoom(id: number){
  this.router.navigate(['/detailsadmin',id]);
 }
  admin(){
    this.router.navigate(['admin'])
  }
}
