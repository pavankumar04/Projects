import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoombyidComponent } from './roombyid.component';

describe('RoombyidComponent', () => {
  let component: RoombyidComponent;
  let fixture: ComponentFixture<RoombyidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoombyidComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoombyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
