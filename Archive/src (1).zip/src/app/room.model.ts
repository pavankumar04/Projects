export class Room {
        roomId!:number;
        hotelId!:number;
        roomType!:string;
        roomCost!:number;
        roomAvailability!:boolean;
    
         constructor(id:number,hid:number,rtype:string,rcost:number,rava:boolean){
             this.roomId=id;
             this.hotelId=hid;
             this.roomType=rtype;
             this.roomCost=rcost;
             this.roomAvailability=rava;
    
         }
    }

