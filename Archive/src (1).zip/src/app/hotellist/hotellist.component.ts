import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel.model';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-hotellist',
  templateUrl: './hotellist.component.html',
  styleUrls: ['./hotellist.component.css']
})
export class HotellistComponent implements OnInit {

  constructor(private hotelService: HotelService, private router: Router, private route: ActivatedRoute) { }
  hotels!: Hotel[];

  ngOnInit(): void {
    this.loadData()
  }

  loadData(): void{
    this.hotelService.getAllHotels()
    .subscribe(data => {
    console.log(data);
    this.hotels = data;
    }, error => console.log(error));
  }

  goToHome(){
    this.router.navigate(['']);
  }
  
  searchByLocation(){
    this.router.navigate(['/Search_by_location']);
  }
  golistrooms(){
    this.router.navigate(['listrooms'])
  }
}
