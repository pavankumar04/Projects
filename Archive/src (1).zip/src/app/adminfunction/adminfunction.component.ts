import { error } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Hotel } from '../hotel.model';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-adminfunction',
  templateUrl: './adminfunction.component.html',
  styleUrls: ['./adminfunction.component.css']
})
export class AdminfunctionComponent implements OnInit {
  hotel: Hotel={
     hotelId:0,
    hotelName:'',
    hotelAddress:'',
    hotelPhoneNo:'',
    hotelLocation:'',
    description:''
  }
  hotel1: Hotel={
    hotelId:0,
   hotelName:'',
   hotelAddress:'',
   hotelPhoneNo:'',
   hotelLocation:'',
   description:''
 }
 id!:number;
 promptValue! :string|null;


  constructor(private hotelService: HotelService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
  }
 

  addNewHotel(){
    if(this.hotel.hotelName == '' || this.hotel.hotelAddress == '' || this.hotel.hotelPhoneNo == '' || this.hotel.description == '' || this.hotel.hotelLocation == '') {
      alert("fill all fields")
    }
    if(this.hotel.hotelPhoneNo.length <= 9 || this.hotel.hotelPhoneNo.length >= 12){
      alert("Enter valid Phone Number");
    }
    else{
    this.hotelService.addNewHotel(this.hotel)
    .subscribe(data =>{
      console.log(data);
      alert("Added Successfully");
    },error =>{console.log(error);});
  }
  }
  goToList(){
    this.router.navigate(['Admin_hotelList']);
  }

  deleteHotel(){
    this.promptValue = prompt("Enter Id of the hotel that is to be deleted", '');
    if(this.promptValue != null){
      this.id = + this.promptValue;
    }
    this.hotelService.deleteHotel(this.id)
    .subscribe(data => {
      console.log(data);
      alert(data);
     
    },error =>{alert("wrong entry, no value deleted")});
  }

  goToHome(){
    this.router.navigate(['']);
  }

  updatePhoneNumber(){
    if(this.hotel1.hotelPhoneNo == '' || this.hotel1.hotelId == 0){
      alert("Fill Phone number and Id")
    }
    if(this.hotel1.hotelPhoneNo.length <= 9 || this.hotel1.hotelPhoneNo.length >= 12){
      alert("Enter valid Phone Number");
    }
    else{
    this.hotelService.updatePhoneNo(this.hotel1)
    .subscribe(data =>{
        console.log(data);
        alert(data);
    });
  }
  }

  updateDesc(){
    if(this.hotel1.description == '' || this.hotel1.hotelId == 0){
      alert("Fill Phone number and Id")
    }
    else{
    this.hotelService.updateDesc(this.hotel1)
    .subscribe(data =>{
        console.log(data);
        alert(data);
    });
    }
  }

}


