import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchbyhotelComponent } from './searchbyhotel.component';

describe('SearchbyhotelComponent', () => {
  let component: SearchbyhotelComponent;
  let fixture: ComponentFixture<SearchbyhotelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchbyhotelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchbyhotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
