import { IfStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Hotel } from '../hotel.model';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-searchbyhotel',
  templateUrl: './searchbyhotel.component.html',
  styleUrls: ['./searchbyhotel.component.css']
})
export class SearchbyhotelComponent implements OnInit {

  hotel!: Hotel[]|null;
  hotel1!: Hotel|null;
  location!: string;
  id: number = 0;
  promptValue?: string|null;

  
  
  
  constructor(private router: Router, private hotelService: HotelService) { }

  ngOnInit(): void {
    
  }

  refresh(){
    this.hotel1 = null;
    this.hotel = null;
  }
  
  showHotelDetails(){
    this.refresh();
    this.hotelService.getHotelByLocation(this.location)
    .subscribe( data => {
      console.log(data);
      this.hotel =data;
      if(this.hotel.length == 0 ){
        alert("No hotel found");
      }
    },error =>{alert("invalid input")});
   
    }

    goToHome(){
      this.router.navigate(['']);
    }
  
    searchById(){
      this.refresh();
       this.promptValue = prompt('Enter the hotel Id', "0");
       if(this.promptValue != null){
          this.id= +this.promptValue;
       }
      else{
        this.id = 0;
      }
       this.hotelService.getHotelById(this.id)
    .subscribe( data => {
      console.log(data);
       this.hotel1 =data;
       
    },error =>{alert("invalid input")});
 
    }
    
    goToAllHotel(){
      this.router.navigate(["/allHotel"]);
    }
}
