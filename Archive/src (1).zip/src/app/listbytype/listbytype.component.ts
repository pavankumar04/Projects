import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-listbytype',
  templateUrl: './listbytype.component.html',
  styleUrls: ['./listbytype.component.css']
})
export class ListbytypeComponent implements OnInit {
  room!: Room[];
    rtype!: string;
   

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    
    

  }
  showRoomsByType(){
   
    this.roomservice.listByRoomType(this.rtype)
    .subscribe( data => {
      console.log(data);
      this.room =data;
      if(data.length==0){
        alert("THERE IS NO SUCH ROOM TYPE")
      }
    },error=>{alert("ENTER A VALID TYPE")});
      
}
showRoomById(id: number){
  this.router.navigate(['/details',id]); 
}
listByAvail(){
  this.router.navigate(['RoomsAvail'])
}
home(){
  this.router.navigate(['']);
}

}
