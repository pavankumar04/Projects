import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListbytypeComponent } from './listbytype.component';

describe('ListbytypeComponent', () => {
  let component: ListbytypeComponent;
  let fixture: ComponentFixture<ListbytypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListbytypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListbytypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
