import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { subscribeOn } from 'rxjs/operators';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-addroom',
  templateUrl: './addroom.component.html',
  styleUrls: ['./addroom.component.css']
})
export class AddroomComponent implements OnInit {
  room: Room={
    roomId:0,
    hotelId:0,
    roomType:'',
    roomCost:0,
    roomAvailability!:true
  }

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.addroom

  }
  addroom(){

    if(this.room.hotelId==0 || this.room.roomType==''|| this.room.roomCost==0||this.room.roomAvailability!=true||false){
      alert("ENTERED VALUES ARE NOT VALID / NO VALUES ENTERED")
    }
    else{
    this.roomservice.addRoom(this.room)
    .subscribe(data=>{
      console.log(data);
      alert("ROOM ADDED SUCCESSFULLY");
      if(data==null){
        alert("VALUES ENTERED ARE INVALID")
      }

    },error=>{alert("ENTER VALID HOTEL-ID")});
    
  }
}
  home1(){
    this.router.navigate([''])
  }
  admin(){
    this.router.navigate(['admin'])
  }
  
}
