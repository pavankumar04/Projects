import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecostComponent } from './updatecost.component';

describe('UpdatecostComponent', () => {
  let component: UpdatecostComponent;
  let fixture: ComponentFixture<UpdatecostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatecostComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatecostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
