import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-updatecost',
  templateUrl: './updatecost.component.html',
  styleUrls: ['./updatecost.component.css']
})
export class UpdatecostComponent implements OnInit {
  room: Room={
    roomId:0,
    hotelId:0,
    roomType:'',
    roomCost:0,
    roomAvailability!:true
  }
  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
  
  }
  updatecost(){
    if(this.room.roomId==0||this.room.roomCost==0||this.room.roomCost<0||this.room.roomId>=1000){
      alert("UPDATE UNSUCCESSFULL-EITHER ROOMID (OR) COST IS INVAILD")
    }
    else{
    this.roomservice.updateRoomCost(this.room)
    .subscribe(data =>{
        console.log(data);
        alert((data));
        if(data==null){
          alert("ROOM ID IS NOT VALID");
        }
    },error=>{alert("ENTER A VALID TYPE")});
  }
  }
  home(){
    this.router.navigate([''])
  }
  admin(){
    this.router.navigate(['admin'])
  }
}
