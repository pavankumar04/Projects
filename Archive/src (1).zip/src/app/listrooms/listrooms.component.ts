import{Room} from './../room.model';
import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-listrooms',
  templateUrl: './listrooms.component.html',
  styleUrls: ['./listrooms.component.css']
})
export class ListroomsComponent implements OnInit {

 room!: Room[];



  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute ) { }

  ngOnInit(): void {
    this.retrieveRooms();
    
    
    
  }
  

  retrieveRooms():void{
    this.roomservice.listAllRooms()
    .subscribe(
      data=>{
        console.log(data);
        this.room=data;
        
        
      }
    )
  
}
showRoomById(id: number){
  this.router.navigate(['/details',id]); 
}
show(){
  this.router.navigate(['SearchByType']);
}
listByAvail(){
  this.router.navigate(['RoomsAvail'])
}
fil(){
  this.router.navigate(['fil']);
}
home(){
  this.router.navigate(['']);
}


}