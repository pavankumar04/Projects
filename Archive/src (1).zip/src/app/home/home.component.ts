import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute ) { }

  ngOnInit(): void {
  }
  retrieveRooms(){
    this.router.navigate(['listrooms']);
  }
  admin(){
    this.router.navigate(['admin']);
  }
  listhotels(){
    this.router.navigate(['allHotel'])
  }


}
