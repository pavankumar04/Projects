import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ListroomsComponent } from './listrooms/listrooms.component';
import { RoomdetailsComponent } from './roomdetails/roomdetails.component';
import { ListbytypeComponent } from './listbytype/listbytype.component';
import { RoomsavailComponent } from './roomsavail/roomsavail.component';
import { FilterComponent } from './filter/filter.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AddroomComponent } from './addroom/addroom.component';
import { ListroomsadminComponent } from './listroomsadmin/listroomsadmin.component';
import { RoomdetailsadminComponent } from './roomdetailsadmin/roomdetailsadmin.component';
import { RoombyidComponent } from './roombyid/roombyid.component';
import { RoombyhidComponent } from './roombyhid/roombyhid.component';
import { UpdatecostComponent } from './updatecost/updatecost.component';
import { HotellistComponent } from './hotellist/hotellist.component';
import { AdminfunctionComponent } from './adminfunction/adminfunction.component';
import { SearchbyhotelComponent } from './searchbyhotel/searchbyhotel.component';
import { HotellistadminComponent } from './hotellistadmin/hotellistadmin.component';
import { AdminbookingdetailsComponent } from './adminbookingdetails/adminbookingdetails.component';
import { BadminComponent } from './badmin/badmin.component';
import { BookingdetailsComponent } from './bookingdetails/bookingdetails.component';
import { BuserhomeafterbookingComponent } from './buserhomeafterbooking/buserhomeafterbooking.component';
import { BuseraddbookingComponent } from './buseraddbooking/buseraddbooking.component';
import { BuserhomeComponent } from './buserhome/buserhome.component';
import { BhomeComponent } from './bhome/bhome.component';

const routes: Routes = [
  { path: 'listrooms', component: ListroomsComponent, pathMatch: 'full' },
  { path: 'details/:id', component: RoomdetailsComponent },
  { path: 'SearchByType', component: ListbytypeComponent, pathMatch: 'full' },
  { path: 'RoomsAvail', component: RoomsavailComponent, pathMatch: 'full' },
  { path: 'fil', component: FilterComponent, pathMatch: 'full' },
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'admin', component: AdminComponent, pathMatch: 'full' },
  { path: 'addroom', component: AddroomComponent, pathMatch: 'full' },
  {
    path: 'listroomsadmin',
    component: ListroomsadminComponent,
    pathMatch: 'full',
  },
  { path: 'detailsadmin/:id', component: RoomdetailsadminComponent },
  { path: 'searchbyid', component: RoombyidComponent },
  { path: 'searchhid', component: RoombyhidComponent },
  { path: 'cost', component: UpdatecostComponent },
  { path: 'allHotel', component: HotellistComponent, pathMatch: 'full' },
  {
    path: 'Admin_function',
    component: AdminfunctionComponent,
    pathMatch: 'full',
  },
  {
    path: 'Search_by_location',
    component: SearchbyhotelComponent,
    pathMatch: 'full',
  },
  {
    path: 'Admin_hotelList',
    component: HotellistadminComponent,
    pathMatch: 'full',
  },
  { path: 'bhome/admin/:bid', component: AdminbookingdetailsComponent },
  { path: 'bhome/admin', component: BadminComponent },
  {
    path: 'bhome/user/home/details/:gid/:bid',
    component: BookingdetailsComponent,
  },
  { path: 'bhome/user/home/:gid', component: BuserhomeafterbookingComponent },
  { path: 'bhome/user/home', component: BuserhomeafterbookingComponent },
  { path: 'cart/:gid/:hid/:rid/:cost', component: BuseraddbookingComponent },
  { path: 'bhome/user', component: BuserhomeComponent },
  { path: 'bhome', component: BhomeComponent },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
