import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomsavailComponent } from './roomsavail.component';

describe('RoomsavailComponent', () => {
  let component: RoomsavailComponent;
  let fixture: ComponentFixture<RoomsavailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoomsavailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoomsavailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
