import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-roomsavail',
  templateUrl: './roomsavail.component.html',
  styleUrls: ['./roomsavail.component.css']
})
export class RoomsavailComponent implements OnInit {
  room!:Room[];
  rava!:boolean;

  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.listByAvail()
    

   
  }

  listByAvail(){
    this.roomservice.listByAvail(this.rava)
    .subscribe( data => {
      console.log(data);
      this.room =data;
    });
}
showRoomById(id: number){
  this.router.navigate(['/details',id]); 
}
showRoom(id:number){
  this.router.navigate(['/detailsadmin',id]);
}
show(){
  this.router.navigate(['SearchByType']);
}
home(){
  this.router.navigate(['']);
}


}
