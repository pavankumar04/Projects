import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomdetailsadminComponent } from './roomdetailsadmin.component';

describe('RoomdetailsadminComponent', () => {
  let component: RoomdetailsadminComponent;
  let fixture: ComponentFixture<RoomdetailsadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoomdetailsadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoomdetailsadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
