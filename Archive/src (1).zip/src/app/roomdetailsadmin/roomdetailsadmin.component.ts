import { UpperCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-roomdetailsadmin',
  templateUrl: './roomdetailsadmin.component.html',
  styleUrls: ['./roomdetailsadmin.component.css']
})
export class RoomdetailsadminComponent implements OnInit {

  id!:number;
  room!:Room;
  availiabilty!:boolean;

  
  constructor(private roomService:RoomService ,private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.id =this.route.snapshot.params['id'];
    this.showRoomById();
  }
  clickAvail(){
   
    this.availiabilty= true;
    this.room.roomAvailability= this.availiabilty;
    alert("click on Update to save changes")
  }

  clickNotAvail(){
    
    this.availiabilty= false;
    this.room.roomAvailability= this.availiabilty;
    alert("click on Update to save changes")
  }

  updateRoomAvail(){
  
    this.roomService.updateRoomAvail(this.room)
    .subscribe(data =>{
        console.log(data);
        alert(data);
    });
  }
  deleteRoom(id:number){
    this.roomService.deleteRoom(this.id)
    .subscribe(data=>{
      console.log(data);
      alert(data);
      this.home();
    }) 
  }
  



  showRoomById(){
    this.roomService.getRoomById(this.id)
    .subscribe(data=> {
      console.log(data);
      this.room=data;

    })
  }
  home(){
    this.router.navigate(['']);
  }
  admin(){
    this.router.navigate(['admin'])
  }

}
