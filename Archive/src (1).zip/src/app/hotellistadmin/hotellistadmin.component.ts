import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Hotel } from '../hotel.model';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-hotellistadmin',
  templateUrl: './hotellistadmin.component.html',
  styleUrls: ['./hotellistadmin.component.css']
})
export class HotellistadminComponent implements OnInit {

  hotels!: Hotel[];
  constructor(private hotelService: HotelService, private router: Router) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void{
    this.hotelService.getAllHotels()
    .subscribe(data => {
    console.log(data);
    this.hotels = data;
    }, error => console.log(error));
  }

  goToHome(){
    this.router.navigate(['']);
  }
  goToAdminFunction(){
    this.router.navigate(["/Admin_function"]);
  }
}
