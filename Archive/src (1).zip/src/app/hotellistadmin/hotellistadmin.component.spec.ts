import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotellistadminComponent } from './hotellistadmin.component';

describe('HotellistadminComponent', () => {
  let component: HotellistadminComponent;
  let fixture: ComponentFixture<HotellistadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotellistadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotellistadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
