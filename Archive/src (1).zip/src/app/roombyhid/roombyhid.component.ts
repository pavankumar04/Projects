import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-roombyhid',
  templateUrl: './roombyhid.component.html',
  styleUrls: ['./roombyhid.component.css']
})
export class RoombyhidComponent implements OnInit {
 
    room!: Room[];
    id!: number;
  
  constructor(private roomservice:RoomService , private router: Router, private route: ActivatedRoute) { }
  
  ngOnInit(): void {
    
    
  
  }
  showRoomById(){
    if(this.id <=0 ||  this.id>=1000){
      alert("CHECK HOTEL ID")
    }
    else{
      this.roomservice.listByHotel(this.id)
    .subscribe(data => {
      console.log(data);
      this.room =data;
      if(data.length==0){
        alert("NOT A VALID HOTEL-ID")
      }
    },error=>{alert("HOTEL ID NOT VALID")});
  }
  }
  home(){
    this.router.navigate(['']);
  }
  showRoom(id: number){
    this.router.navigate(['/detailsadmin',id]); 
  }
  admin(){
    this.router.navigate(['admin'])
  }
  
  }
  