import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoombyhidComponent } from './roombyhid.component';

describe('RoombyhidComponent', () => {
  let component: RoombyhidComponent;
  let fixture: ComponentFixture<RoombyhidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoombyhidComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoombyhidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
