import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ListroomsComponent } from './listrooms/listrooms.component';
import { AppRoutingModule } from './app-routing.module';
import { RoomdetailsComponent } from './roomdetails/roomdetails.component';
import { ListbytypeComponent } from './listbytype/listbytype.component';
import { RoomsavailComponent } from './roomsavail/roomsavail.component';
import { FilterComponent } from './filter/filter.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AddroomComponent } from './addroom/addroom.component';
import { ListroomsadminComponent } from './listroomsadmin/listroomsadmin.component';
import { RoomdetailsadminComponent } from './roomdetailsadmin/roomdetailsadmin.component';
import { RoombyidComponent } from './roombyid/roombyid.component';
import { RoombyhidComponent } from './roombyhid/roombyhid.component';
import { UpdatecostComponent } from './updatecost/updatecost.component';
import { HotellistComponent } from './hotellist/hotellist.component';
import { AdminfunctionComponent } from './adminfunction/adminfunction.component';
import { HotellistadminComponent } from './hotellistadmin/hotellistadmin.component';
import { SearchbyhotelComponent } from './searchbyhotel/searchbyhotel.component';
import { AdminbookingdetailsComponent } from './adminbookingdetails/adminbookingdetails.component';
import { BadminComponent } from './badmin/badmin.component';
import { BhomeComponent } from './bhome/bhome.component';
import { BookingdetailsComponent } from './bookingdetails/bookingdetails.component';
import { BuserhomeComponent } from './buserhome/buserhome.component';
import { BuserhomeafterbookingComponent } from './buserhomeafterbooking/buserhomeafterbooking.component';
import { BuseraddbookingComponent } from './buseraddbooking/buseraddbooking.component';

@NgModule({
  declarations: [
    AppComponent,
    ListroomsComponent,
    RoomdetailsComponent,
    ListbytypeComponent,
    RoomsavailComponent,
    FilterComponent,
    HomeComponent,
    AdminComponent,
    AddroomComponent,
    ListroomsadminComponent,
    RoomdetailsadminComponent,
    RoombyidComponent,
    RoombyhidComponent,
    UpdatecostComponent,
    HotellistComponent,
    AdminfunctionComponent,
    HotellistadminComponent,
    SearchbyhotelComponent,
    AdminbookingdetailsComponent,
    BadminComponent,
    BhomeComponent,
    BookingdetailsComponent,
    BuserhomeComponent,
    BuserhomeafterbookingComponent,
    BuseraddbookingComponent,
  ],
  imports: [BrowserModule, FormsModule, HttpClientModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
