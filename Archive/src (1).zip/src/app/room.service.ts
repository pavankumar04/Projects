import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Room } from './room.model';
import {map} from 'rxjs/operators';

const baseUrl:string='http://localhost:8086/api/rooms';
@Injectable({
  providedIn: 'root'
})
export class RoomService {
   

  constructor(private http:HttpClient) { }
  listAllRooms():Observable<Room[]>{
    return this.http.get<Room[]>(baseUrl);
  }
 getRoomById(id:number):Observable<Room>{
    return this.http.get<Room>(`${baseUrl}/room/${id}`);
  }
  listByRoomType(rtype:string):Observable<Room[]>{
    return this.http.get<Room[]>(`${baseUrl}/type/${rtype}`);
  }
  listByAvail(rava:boolean):Observable<Room[]>{
    return this.http.get<Room[]>(`${baseUrl}/avail`);
  }
  listByFilter(cost:number):Observable<Room[]>{
    return this.http.get<Room[]>(`${baseUrl}/filterbycost/${cost}`);
  }
  addRoom(room:Room):Observable<any>{
    return this.http.post(`${baseUrl}/addroom`,room,
    {headers:{'content-type':'application/json'},observe:'response',responseType:'text'})
    .pipe(map(data=>{
      console.log(data.body);
      return data.body;
    }));
    

}
deleteRoom(id:number):Observable<any>{
  return this.http.delete(`${baseUrl}/removeroom/${id}`,
  {headers:{'content-type':'application/json'},observe:'response',responseType:'text'})
  .pipe(map(data=>{
    console.log(data.body);
    return data.body;
  }));

} 
listByHotel(hid:number):Observable<Room[]>{
  return this.http.get<Room[]>(`${baseUrl}/hotel/${hid}`);
}
  
updateRoomAvail(room:Room):Observable<any>{
  return this.http.put(`${baseUrl}/updateavailabilty/${room.roomAvailability}/${room.roomId}`,room,
  {headers:{'content-type':'application/json'},observe:'response',responseType:'text'})
  .pipe(map(data=>{
    console.log(data.body);
    return data.body;
  }));
}
updateRoomCost(room:Room):Observable<any>{
  return this.http.put(`${baseUrl}/cost/${room.roomCost}/${room.roomId}`,room,
  {headers:{'content-type':'application/json'},observe:'response',responseType:'text'})
  .pipe(map(data=>{
    console.log(data.body);
    return data.body;
  }));
}
   /*
  
 

  

  
    */

}