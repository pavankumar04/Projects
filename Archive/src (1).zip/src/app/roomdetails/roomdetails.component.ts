import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../room.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-roomdetails',
  templateUrl: './roomdetails.component.html',
  styleUrls: ['./roomdetails.component.css'],
})
export class RoomdetailsComponent implements OnInit {
  id!: number;
  room!: Room;

  constructor(
    private roomService: RoomService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.showRoomById(this.id);
  }

  showRoomById(id: number) {
    this.roomService.getRoomById(id).subscribe((data) => {
      console.log(data);
      this.room = data;
    });
  }

  bookRoom() {
    console.log(this.room.roomId, this.room.hotelId, this.room.roomCost);
    this.router.navigate([
      '/cart',
      101,
      this.room.hotelId,
      this.room.roomId,
      this.room.roomCost,
    ]);
  }
  home() {
    this.router.navigate(['']);
  }
}
